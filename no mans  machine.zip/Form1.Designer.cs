﻿namespace noMansResourceMachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.priradit = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.kompilovat = new System.Windows.Forms.Button();
            this.jumpIf = new System.Windows.Forms.Panel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.skocKdyzLabel = new System.Windows.Forms.Label();
            this.comboBox35 = new System.Windows.Forms.ComboBox();
            this.inputPanel = new System.Windows.Forms.Panel();
            this.vstupLabel = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.jump = new System.Windows.Forms.Panel();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.skocLabel = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.output = new System.Windows.Forms.Panel();
            this.vystupLabel = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.prirad = new System.Windows.Forms.Panel();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.priradLabel = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.pricti = new System.Windows.Forms.Panel();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.prictiLabel = new System.Windows.Forms.Label();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.odecti = new System.Windows.Forms.Panel();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.odectiLabel = new System.Windows.Forms.Label();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.pricti1 = new System.Windows.Forms.Panel();
            this.pricti1Label = new System.Windows.Forms.Label();
            this.comboBox31 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.odecti1 = new System.Windows.Forms.Panel();
            this.odecti1Label = new System.Windows.Forms.Label();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.button8 = new System.Windows.Forms.Button();
            this.comboBox34 = new System.Windows.Forms.ComboBox();
            this.konzole = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel_scrolllll = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.velikostKroku = new System.Windows.Forms.TextBox();
            this.zadani = new System.Windows.Forms.TextBox();
            this.inputTB = new System.Windows.Forms.TextBox();
            this.outputTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.napSkocKdyz = new System.Windows.Forms.Button();
            this.napSkoc = new System.Windows.Forms.Button();
            this.napPricti1 = new System.Windows.Forms.Button();
            this.napOdecti1 = new System.Windows.Forms.Button();
            this.napOdecti = new System.Windows.Forms.Button();
            this.napPricti = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.napVystup = new System.Windows.Forms.Button();
            this.napVstup = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.prijmeni = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textPrijmeni = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.jumpIf.SuspendLayout();
            this.inputPanel.SuspendLayout();
            this.jump.SuspendLayout();
            this.output.SuspendLayout();
            this.prirad.SuspendLayout();
            this.pricti.SuspendLayout();
            this.odecti.SuspendLayout();
            this.pricti1.SuspendLayout();
            this.odecti1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // priradit
            // 
            resources.ApplyResources(this.priradit, "priradit");
            this.priradit.Name = "priradit";
            this.priradit.UseVisualStyleBackColor = true;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox3, "comboBox3");
            this.comboBox3.Name = "comboBox3";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox5, "comboBox5");
            this.comboBox5.Name = "comboBox5";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox6, "comboBox6");
            this.comboBox6.Name = "comboBox6";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox7, "comboBox7");
            this.comboBox7.Name = "comboBox7";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox8, "comboBox8");
            this.comboBox8.Name = "comboBox8";
            // 
            // kompilovat
            // 
            resources.ApplyResources(this.kompilovat, "kompilovat");
            this.kompilovat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.kompilovat.Name = "kompilovat";
            this.kompilovat.UseVisualStyleBackColor = true;
            this.kompilovat.Click += new System.EventHandler(this.kompilovat_Click);
            // 
            // jumpIf
            // 
            resources.ApplyResources(this.jumpIf, "jumpIf");
            this.jumpIf.BackColor = System.Drawing.Color.Blue;
            this.jumpIf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.jumpIf.Controls.Add(this.comboBox4);
            this.jumpIf.Controls.Add(this.skocKdyzLabel);
            this.jumpIf.Controls.Add(this.comboBox35);
            this.jumpIf.Controls.Add(this.comboBox5);
            this.jumpIf.Controls.Add(this.priradit);
            this.jumpIf.Controls.Add(this.comboBox6);
            this.jumpIf.Controls.Add(this.comboBox7);
            this.jumpIf.Controls.Add(this.comboBox3);
            this.jumpIf.Name = "jumpIf";
            this.jumpIf.Tag = "\"jumpIf\"";
            this.jumpIf.Click += new System.EventHandler(this.jumpIf_Click);
            this.jumpIf.Paint += new System.Windows.Forms.PaintEventHandler(this.jumpIf_Paint);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox4, "comboBox4");
            this.comboBox4.Name = "comboBox4";
            // 
            // skocKdyzLabel
            // 
            resources.ApplyResources(this.skocKdyzLabel, "skocKdyzLabel");
            this.skocKdyzLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.skocKdyzLabel.Name = "skocKdyzLabel";
            this.skocKdyzLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.skocKdyzLabel_MouseClick);
            // 
            // comboBox35
            // 
            this.comboBox35.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox35, "comboBox35");
            this.comboBox35.Name = "comboBox35";
            // 
            // inputPanel
            // 
            resources.ApplyResources(this.inputPanel, "inputPanel");
            this.inputPanel.BackColor = System.Drawing.Color.Green;
            this.inputPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.inputPanel.Controls.Add(this.vstupLabel);
            this.inputPanel.Controls.Add(this.comboBox1);
            this.inputPanel.Controls.Add(this.button1);
            this.inputPanel.Controls.Add(this.comboBox2);
            this.inputPanel.Controls.Add(this.comboBox8);
            this.inputPanel.Name = "inputPanel";
            this.inputPanel.Tag = "\"vstup\"";
            this.inputPanel.Click += new System.EventHandler(this.inputPanel_Click);
            // 
            // vstupLabel
            // 
            resources.ApplyResources(this.vstupLabel, "vstupLabel");
            this.vstupLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.vstupLabel.Name = "vstupLabel";
            this.vstupLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.vstupLabel_MouseClick);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox1, "comboBox1");
            this.comboBox1.Name = "comboBox1";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox2, "comboBox2");
            this.comboBox2.Name = "comboBox2";
            // 
            // jump
            // 
            resources.ApplyResources(this.jump, "jump");
            this.jump.BackColor = System.Drawing.Color.Blue;
            this.jump.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.jump.Controls.Add(this.comboBox11);
            this.jump.Controls.Add(this.skocLabel);
            this.jump.Controls.Add(this.comboBox9);
            this.jump.Controls.Add(this.button5);
            this.jump.Controls.Add(this.comboBox10);
            this.jump.Name = "jump";
            this.jump.Tag = "\"jump\"";
            this.jump.Click += new System.EventHandler(this.jump_Click);
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox11, "comboBox11");
            this.comboBox11.Name = "comboBox11";
            // 
            // skocLabel
            // 
            resources.ApplyResources(this.skocLabel, "skocLabel");
            this.skocLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.skocLabel.Name = "skocLabel";
            this.skocLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.skocLabel_MouseClick);
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox9, "comboBox9");
            this.comboBox9.Name = "comboBox9";
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox10, "comboBox10");
            this.comboBox10.Name = "comboBox10";
            // 
            // output
            // 
            resources.ApplyResources(this.output, "output");
            this.output.BackColor = System.Drawing.Color.Green;
            this.output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.output.Controls.Add(this.vystupLabel);
            this.output.Controls.Add(this.comboBox12);
            this.output.Controls.Add(this.button6);
            this.output.Controls.Add(this.comboBox13);
            this.output.Controls.Add(this.comboBox14);
            this.output.Name = "output";
            this.output.Tag = "\"vystup\"";
            this.output.MouseClick += new System.Windows.Forms.MouseEventHandler(this.output_MouseClick);
            // 
            // vystupLabel
            // 
            resources.ApplyResources(this.vystupLabel, "vystupLabel");
            this.vystupLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.vystupLabel.Name = "vystupLabel";
            this.vystupLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.vystupLabel_MouseClick);
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox12, "comboBox12");
            this.comboBox12.Name = "comboBox12";
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox13, "comboBox13");
            this.comboBox13.Name = "comboBox13";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox14, "comboBox14");
            this.comboBox14.Name = "comboBox14";
            // 
            // prirad
            // 
            resources.ApplyResources(this.prirad, "prirad");
            this.prirad.BackColor = System.Drawing.Color.Olive;
            this.prirad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.prirad.Controls.Add(this.comboBox18);
            this.prirad.Controls.Add(this.comboBox15);
            this.prirad.Controls.Add(this.priradLabel);
            this.prirad.Controls.Add(this.comboBox16);
            this.prirad.Controls.Add(this.button2);
            this.prirad.Controls.Add(this.comboBox17);
            this.prirad.Name = "prirad";
            this.prirad.Tag = "\"prirad\"";
            this.prirad.Click += new System.EventHandler(this.prirad_Click);
            this.prirad.Paint += new System.Windows.Forms.PaintEventHandler(this.prirad_Paint);
            // 
            // comboBox18
            // 
            this.comboBox18.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox18, "comboBox18");
            this.comboBox18.Name = "comboBox18";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox15, "comboBox15");
            this.comboBox15.Name = "comboBox15";
            // 
            // priradLabel
            // 
            resources.ApplyResources(this.priradLabel, "priradLabel");
            this.priradLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.priradLabel.Name = "priradLabel";
            this.priradLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.priradLabel_MouseClick);
            // 
            // comboBox16
            // 
            this.comboBox16.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox16, "comboBox16");
            this.comboBox16.Name = "comboBox16";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // comboBox17
            // 
            this.comboBox17.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox17, "comboBox17");
            this.comboBox17.Name = "comboBox17";
            // 
            // pricti
            // 
            resources.ApplyResources(this.pricti, "pricti");
            this.pricti.BackColor = System.Drawing.Color.Firebrick;
            this.pricti.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pricti.Controls.Add(this.comboBox19);
            this.pricti.Controls.Add(this.comboBox20);
            this.pricti.Controls.Add(this.prictiLabel);
            this.pricti.Controls.Add(this.comboBox21);
            this.pricti.Controls.Add(this.button3);
            this.pricti.Controls.Add(this.comboBox22);
            this.pricti.Name = "pricti";
            this.pricti.Tag = "\"pricti\"";
            this.pricti.Click += new System.EventHandler(this.pricti_Click);
            // 
            // comboBox19
            // 
            this.comboBox19.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox19, "comboBox19");
            this.comboBox19.Name = "comboBox19";
            // 
            // comboBox20
            // 
            this.comboBox20.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox20, "comboBox20");
            this.comboBox20.Name = "comboBox20";
            // 
            // prictiLabel
            // 
            resources.ApplyResources(this.prictiLabel, "prictiLabel");
            this.prictiLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.prictiLabel.Name = "prictiLabel";
            this.prictiLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.prictiLabel_MouseClick);
            // 
            // comboBox21
            // 
            this.comboBox21.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox21, "comboBox21");
            this.comboBox21.Name = "comboBox21";
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // comboBox22
            // 
            this.comboBox22.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox22, "comboBox22");
            this.comboBox22.Name = "comboBox22";
            // 
            // odecti
            // 
            resources.ApplyResources(this.odecti, "odecti");
            this.odecti.BackColor = System.Drawing.Color.Firebrick;
            this.odecti.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.odecti.Controls.Add(this.comboBox23);
            this.odecti.Controls.Add(this.comboBox24);
            this.odecti.Controls.Add(this.odectiLabel);
            this.odecti.Controls.Add(this.comboBox25);
            this.odecti.Controls.Add(this.button4);
            this.odecti.Controls.Add(this.comboBox26);
            this.odecti.Name = "odecti";
            this.odecti.Tag = "\"odecti\"";
            this.odecti.MouseClick += new System.Windows.Forms.MouseEventHandler(this.odecti_MouseClick);
            // 
            // comboBox23
            // 
            this.comboBox23.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox23, "comboBox23");
            this.comboBox23.Name = "comboBox23";
            // 
            // comboBox24
            // 
            this.comboBox24.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox24, "comboBox24");
            this.comboBox24.Name = "comboBox24";
            // 
            // odectiLabel
            // 
            resources.ApplyResources(this.odectiLabel, "odectiLabel");
            this.odectiLabel.BackColor = System.Drawing.Color.Firebrick;
            this.odectiLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.odectiLabel.Name = "odectiLabel";
            this.odectiLabel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.odectiLabel_MouseClick);
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox25, "comboBox25");
            this.comboBox25.Name = "comboBox25";
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // comboBox26
            // 
            this.comboBox26.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox26, "comboBox26");
            this.comboBox26.Name = "comboBox26";
            // 
            // pricti1
            // 
            resources.ApplyResources(this.pricti1, "pricti1");
            this.pricti1.BackColor = System.Drawing.Color.DarkOrange;
            this.pricti1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pricti1.Controls.Add(this.pricti1Label);
            this.pricti1.Controls.Add(this.comboBox31);
            this.pricti1.Controls.Add(this.label8);
            this.pricti1.Controls.Add(this.comboBox29);
            this.pricti1.Controls.Add(this.button7);
            this.pricti1.Controls.Add(this.comboBox30);
            this.pricti1.Name = "pricti1";
            this.pricti1.Tag = "\"priciti1\"";
            this.pricti1.Click += new System.EventHandler(this.pricti1_Click);
            // 
            // pricti1Label
            // 
            resources.ApplyResources(this.pricti1Label, "pricti1Label");
            this.pricti1Label.BackColor = System.Drawing.Color.DarkOrange;
            this.pricti1Label.ForeColor = System.Drawing.SystemColors.Control;
            this.pricti1Label.Name = "pricti1Label";
            this.pricti1Label.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pricti1Label_MouseClick);
            // 
            // comboBox31
            // 
            this.comboBox31.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox31, "comboBox31");
            this.comboBox31.Name = "comboBox31";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.Firebrick;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Name = "label8";
            // 
            // comboBox29
            // 
            this.comboBox29.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox29, "comboBox29");
            this.comboBox29.Name = "comboBox29";
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // comboBox30
            // 
            this.comboBox30.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox30, "comboBox30");
            this.comboBox30.Name = "comboBox30";
            // 
            // odecti1
            // 
            resources.ApplyResources(this.odecti1, "odecti1");
            this.odecti1.BackColor = System.Drawing.Color.DarkOrange;
            this.odecti1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.odecti1.Controls.Add(this.odecti1Label);
            this.odecti1.Controls.Add(this.comboBox27);
            this.odecti1.Controls.Add(this.label11);
            this.odecti1.Controls.Add(this.comboBox33);
            this.odecti1.Controls.Add(this.button8);
            this.odecti1.Controls.Add(this.comboBox34);
            this.odecti1.Name = "odecti1";
            this.odecti1.Tag = "\"odecti1\"";
            this.odecti1.Click += new System.EventHandler(this.odecti1_Click);
            // 
            // odecti1Label
            // 
            resources.ApplyResources(this.odecti1Label, "odecti1Label");
            this.odecti1Label.BackColor = System.Drawing.Color.DarkOrange;
            this.odecti1Label.Cursor = System.Windows.Forms.Cursors.Default;
            this.odecti1Label.ForeColor = System.Drawing.SystemColors.Control;
            this.odecti1Label.Name = "odecti1Label";
            this.odecti1Label.MouseClick += new System.Windows.Forms.MouseEventHandler(this.odecti1Label_MouseClick);
            // 
            // comboBox27
            // 
            this.comboBox27.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox27, "comboBox27");
            this.comboBox27.Name = "comboBox27";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.BackColor = System.Drawing.Color.Firebrick;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label11.Name = "label11";
            // 
            // comboBox33
            // 
            this.comboBox33.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox33, "comboBox33");
            this.comboBox33.Name = "comboBox33";
            // 
            // button8
            // 
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // comboBox34
            // 
            this.comboBox34.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox34, "comboBox34");
            this.comboBox34.Name = "comboBox34";
            // 
            // konzole
            // 
            resources.ApplyResources(this.konzole, "konzole");
            this.konzole.BackColor = System.Drawing.SystemColors.MenuText;
            this.konzole.ForeColor = System.Drawing.SystemColors.Menu;
            this.konzole.Name = "konzole";
            this.konzole.ReadOnly = true;
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.panel_scrolllll);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // panel_scrolllll
            // 
            resources.ApplyResources(this.panel_scrolllll, "panel_scrolllll");
            this.panel_scrolllll.Name = "panel_scrolllll";
            // 
            // button9
            // 
            resources.ApplyResources(this.button9, "button9");
            this.button9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button9.Name = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // velikostKroku
            // 
            resources.ApplyResources(this.velikostKroku, "velikostKroku");
            this.velikostKroku.Name = "velikostKroku";
            this.velikostKroku.TextChanged += new System.EventHandler(this.velikostKroku_TextChanged);
            // 
            // zadani
            // 
            resources.ApplyResources(this.zadani, "zadani");
            this.zadani.Name = "zadani";
            this.zadani.ReadOnly = true;
            // 
            // inputTB
            // 
            resources.ApplyResources(this.inputTB, "inputTB");
            this.inputTB.Name = "inputTB";
            this.inputTB.ReadOnly = true;
            // 
            // outputTB
            // 
            resources.ApplyResources(this.outputTB, "outputTB");
            this.outputTB.Name = "outputTB";
            this.outputTB.ReadOnly = true;
            this.outputTB.TextChanged += new System.EventHandler(this.outputTB_TextChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Name = "label1";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label13.Name = "label13";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Name = "label15";
            // 
            // napSkocKdyz
            // 
            resources.ApplyResources(this.napSkocKdyz, "napSkocKdyz");
            this.napSkocKdyz.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napSkocKdyz.Name = "napSkocKdyz";
            this.napSkocKdyz.UseVisualStyleBackColor = true;
            this.napSkocKdyz.Click += new System.EventHandler(this.button13_Click);
            // 
            // napSkoc
            // 
            resources.ApplyResources(this.napSkoc, "napSkoc");
            this.napSkoc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napSkoc.Name = "napSkoc";
            this.napSkoc.UseVisualStyleBackColor = true;
            this.napSkoc.Click += new System.EventHandler(this.napSkoc_Click);
            // 
            // napPricti1
            // 
            resources.ApplyResources(this.napPricti1, "napPricti1");
            this.napPricti1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napPricti1.Name = "napPricti1";
            this.napPricti1.UseVisualStyleBackColor = true;
            this.napPricti1.Click += new System.EventHandler(this.napPricti1_Click);
            // 
            // napOdecti1
            // 
            resources.ApplyResources(this.napOdecti1, "napOdecti1");
            this.napOdecti1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napOdecti1.Name = "napOdecti1";
            this.napOdecti1.UseVisualStyleBackColor = true;
            this.napOdecti1.Click += new System.EventHandler(this.napOdecti1_Click);
            // 
            // napOdecti
            // 
            resources.ApplyResources(this.napOdecti, "napOdecti");
            this.napOdecti.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napOdecti.Name = "napOdecti";
            this.napOdecti.UseVisualStyleBackColor = true;
            this.napOdecti.Click += new System.EventHandler(this.napOdecti_Click);
            // 
            // napPricti
            // 
            resources.ApplyResources(this.napPricti, "napPricti");
            this.napPricti.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napPricti.Name = "napPricti";
            this.napPricti.UseVisualStyleBackColor = true;
            this.napPricti.Click += new System.EventHandler(this.napPricti_Click);
            // 
            // button16
            // 
            resources.ApplyResources(this.button16, "button16");
            this.button16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button16.Name = "button16";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // napVystup
            // 
            resources.ApplyResources(this.napVystup, "napVystup");
            this.napVystup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napVystup.Name = "napVystup";
            this.napVystup.UseVisualStyleBackColor = true;
            this.napVystup.Click += new System.EventHandler(this.napVystup_Click);
            // 
            // napVstup
            // 
            resources.ApplyResources(this.napVstup, "napVstup");
            this.napVstup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.napVstup.Name = "napVstup";
            this.napVstup.UseVisualStyleBackColor = true;
            this.napVstup.Click += new System.EventHandler(this.button18_Click);
            // 
            // button10
            // 
            resources.ApplyResources(this.button10, "button10");
            this.button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.Name = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // prijmeni
            // 
            resources.ApplyResources(this.prijmeni, "prijmeni");
            this.prijmeni.Name = "prijmeni";
            this.prijmeni.TextChanged += new System.EventHandler(this.prijmeni_TextChanged);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textPrijmeni
            // 
            resources.ApplyResources(this.textPrijmeni, "textPrijmeni");
            this.textPrijmeni.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textPrijmeni.Name = "textPrijmeni";
            this.textPrijmeni.UseVisualStyleBackColor = true;
            this.textPrijmeni.Click += new System.EventHandler(this.textPrijmeni_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Name = "label3";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textPrijmeni);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.prijmeni);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.napVstup);
            this.Controls.Add(this.napVystup);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.napPricti);
            this.Controls.Add(this.napOdecti);
            this.Controls.Add(this.napOdecti1);
            this.Controls.Add(this.napPricti1);
            this.Controls.Add(this.napSkoc);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.outputTB);
            this.Controls.Add(this.inputTB);
            this.Controls.Add(this.zadani);
            this.Controls.Add(this.velikostKroku);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.konzole);
            this.Controls.Add(this.odecti1);
            this.Controls.Add(this.pricti1);
            this.Controls.Add(this.odecti);
            this.Controls.Add(this.pricti);
            this.Controls.Add(this.prirad);
            this.Controls.Add(this.output);
            this.Controls.Add(this.jump);
            this.Controls.Add(this.inputPanel);
            this.Controls.Add(this.jumpIf);
            this.Controls.Add(this.kompilovat);
            this.Controls.Add(this.napSkocKdyz);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.jumpIf.ResumeLayout(false);
            this.jumpIf.PerformLayout();
            this.inputPanel.ResumeLayout(false);
            this.inputPanel.PerformLayout();
            this.jump.ResumeLayout(false);
            this.jump.PerformLayout();
            this.output.ResumeLayout(false);
            this.output.PerformLayout();
            this.prirad.ResumeLayout(false);
            this.prirad.PerformLayout();
            this.pricti.ResumeLayout(false);
            this.pricti.PerformLayout();
            this.odecti.ResumeLayout(false);
            this.odecti.PerformLayout();
            this.pricti1.ResumeLayout(false);
            this.pricti1.PerformLayout();
            this.odecti1.ResumeLayout(false);
            this.odecti1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button priradit;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Button kompilovat;
        private System.Windows.Forms.Panel jumpIf;
        private System.Windows.Forms.Panel inputPanel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label vstupLabel;
        private System.Windows.Forms.Panel jump;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label skocLabel;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Panel output;
        private System.Windows.Forms.Label vystupLabel;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Panel prirad;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label priradLabel;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Panel pricti;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.Label prictiLabel;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.Panel odecti;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.Label odectiLabel;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.Panel pricti1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.ComboBox comboBox31;
        private System.Windows.Forms.Label pricti1Label;
        private System.Windows.Forms.ComboBox comboBox35;
        private System.Windows.Forms.Panel odecti1;
        private System.Windows.Forms.Label odecti1Label;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox comboBox34;
        private System.Windows.Forms.Label skocKdyzLabel;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox konzole;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel_scrolllll;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox velikostKroku;
        private System.Windows.Forms.TextBox zadani;
        private System.Windows.Forms.TextBox inputTB;
        private System.Windows.Forms.TextBox outputTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button napSkocKdyz;
        private System.Windows.Forms.Button napSkoc;
        private System.Windows.Forms.Button napPricti1;
        private System.Windows.Forms.Button napOdecti1;
        private System.Windows.Forms.Button napOdecti;
        private System.Windows.Forms.Button napPricti;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button napVystup;
        private System.Windows.Forms.Button napVstup;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox prijmeni;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button textPrijmeni;
        private System.Windows.Forms.Label label3;
    }
}

